import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { CholesterolsPage } from './cholesterols.page';

describe('CholesterolsPage', () => {
  let component: CholesterolsPage;
  let fixture: ComponentFixture<CholesterolsPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CholesterolsPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(CholesterolsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
