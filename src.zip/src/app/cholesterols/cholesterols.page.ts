import { Component, OnInit } from '@angular/core';
import {PatientCholesterolService} from '../services/patient-cholesterol.service';

@Component({
  selector: 'app-cholesterols',
  templateUrl: './cholesterols.page.html',
  styleUrls: ['./cholesterols.page.scss'],
})
export class CholesterolsPage implements OnInit {
  private dataCholesterol;
    private patientCholesterol: number;

  constructor(private patientCholesterolService: PatientCholesterolService) { }

  ngOnInit() {
  }

  onLoadPatientCholesterol() {
    this.patientCholesterolService.getCholesteroldata(this.patientCholesterol)
        .subscribe(data => {
          // tslint:disable-next-line:no-unused-expression
          this.dataCholesterol = data;
        }, err => {
          console.log(err);
        });
  }
}
