import { Component, OnInit } from '@angular/core';
import {PatientCholesterolService} from '../services/patient-cholesterol.service';
import {BloodPressureService} from '../services/blood-pressure.service';

@Component({
  selector: 'app-blood-pressures',
  templateUrl: './blood-pressures.page.html',
  styleUrls: ['./blood-pressures.page.scss'],
})
export class BloodPressuresPage implements OnInit {
  private dataBloodPressure;
  private patientBloodPressure: number;

  constructor(private patientBloodPressureService: BloodPressureService) { }

  ngOnInit() {
  }
  onLoadPatientBloodPressure() {
    this.patientBloodPressureService.getBloodPressuredata(this.patientBloodPressure)
        .subscribe(data => {
          // tslint:disable-next-line:no-unused-expression
          this.dataBloodPressure = data;
        }, err => {
          console.log(err);
        });
  }

}
