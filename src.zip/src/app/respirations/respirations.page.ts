import { Component, OnInit } from '@angular/core';
import {BloodPressureService} from '../services/blood-pressure.service';
import {PatientRespirationService} from '../services/patient-respiration.service';

@Component({
  selector: 'app-respirations',
  templateUrl: './respirations.page.html',
  styleUrls: ['./respirations.page.scss'],
})
export class RespirationsPage implements OnInit {
  private dataRespiration;
  private patientRespiration: number;

  constructor(private patientRespirationService: PatientRespirationService) { }

  ngOnInit() {
  }
  onLoadPatientRespiration() {
    this.patientRespirationService.getRespirationdata(this.patientRespiration)
        .subscribe(data => {
          // tslint:disable-next-line:no-unused-expression
          this.dataRespiration = data;
        }, err => {
          console.log(err);
        });
  }

}
