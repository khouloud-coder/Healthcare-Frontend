import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { RespirationsPage } from './respirations.page';

const routes: Routes = [
  {
    path: '',
    component: RespirationsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class RespirationsPageRoutingModule {}
