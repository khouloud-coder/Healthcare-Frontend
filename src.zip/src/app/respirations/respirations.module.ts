import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { RespirationsPageRoutingModule } from './respirations-routing.module';

import { RespirationsPage } from './respirations.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RespirationsPageRoutingModule
  ],
  declarations: [RespirationsPage]
})
export class RespirationsPageModule {}
