import { TestBed } from '@angular/core/testing';

import { PatientCholesterolService } from './patient-cholesterol.service';

describe('PatientCholesterolService', () => {
  let service: PatientCholesterolService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PatientCholesterolService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
