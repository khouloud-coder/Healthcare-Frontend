import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {AuthenticationService} from '../services/authentication.service';


@Component({
  selector: 'app-menu',
  templateUrl: './menu.page.html',
  styleUrls: ['./menu.page.scss'],
})
export class MenuPage implements OnInit {
  public menus = [
    {title: 'Home', url: '/menu/home', icon: 'home'},
    // {title: 'Patient Comments', url: '/menu/patient-comments', icon: 'clipboard'},
    {title: 'Patient Profile', url: '/menu/patient-profile', icon: 'documents'},
    {title: 'Patients', url: '/menu/patients', icon : 'people'},
    {title: 'Respiratory Parameters', url: '/menu/respirations', icon: 'sad'},
    {title: 'Temperatures', url: '/menu/temperatures', icon : 'thermometer'},
    {title: 'Cholesterols', url: '/menu/cholesterols', icon : 'fitness'},
    {title: 'Blood Pressures', url: '/menu/blood-pressures', icon: 'water'},
    {title: 'Logout', url: 'logout', icon : 'log-out'},
  ];

  constructor(private router: Router,
              private authService: AuthenticationService) { }

  ngOnInit() {
  }

  onMenuItem(m) {
    // tslint:disable-next-line:triple-equals
    if (m.url == 'logout'){
      this.authService.logout();
      this.router.navigateByUrl('/login');
    }
    else{
      this.router.navigateByUrl(m.url);
    }

  }
}
