import { Component, OnInit } from '@angular/core';
import {PatientsService} from '../services/patients.service';

@Component({
  selector: 'app-patients',
  templateUrl: './patients.page.html',
  styleUrls: ['./patients.page.scss'],
})
export class PatientsPage implements OnInit {
  private patients;

  constructor(private patientsService: PatientsService) { }

  ngOnInit() {
  }

  onLoadPatients() {
    this.patientsService.getPatients()
          .subscribe(data => {
          // tslint:disable-next-line:no-unused-expression
      this.patients = data;
          // tslint:disable-next-line:no-unused-expression
    }, err => {
      console.log(err);
    });
  }
}
